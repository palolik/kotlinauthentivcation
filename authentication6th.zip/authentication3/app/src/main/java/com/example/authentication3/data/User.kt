package com.example.authentication3.data

import com.google.gson.annotations.SerializedName

data class User(@SerializedName("_id") val id: String, val fulName: String, val email:String)
