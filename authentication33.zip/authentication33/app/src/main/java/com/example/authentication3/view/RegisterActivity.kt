package com.example.authentication3.view

import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.util.Patterns
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.authentication3.R
import com.example.authentication3.databinding.ActivityRegisterBinding
import com.example.authentication3.repository.AuthRepository
import com.example.authentication3.utils.APIConsumer
import com.example.authentication3.utils.APIService
import com.example.authentication3.view_model.RegisterActivityViewModel
import com.example.authentication3.view_model.RegisterActivityViewModelFactory


class RegisterActivity : AppCompatActivity(), View.OnKeyListener,View.OnClickListener,View.OnFocusChangeListener {

    private lateinit var mBinding: ActivityRegisterBinding
    private lateinit var mViewModel: RegisterActivityViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = ActivityRegisterBinding.inflate(LayoutInflater.from(this))
        setContentView(mBinding.root)
        mBinding.fullName.onFocusChangeListener = this
        mBinding.Email.onFocusChangeListener = this
        mBinding.password.onFocusChangeListener = this
        mBinding.passwordre.onFocusChangeListener = this
        mViewModel = ViewModelProvider(this,RegisterActivityViewModelFactory(AuthRepository(APIService.getService()),application)).get(RegisterActivityViewModel:: class.java)
setupObservers()

    }

    private fun setupObservers(){
        mViewModel.getIsLoading().observe(this){

        }
        mViewModel.getErrorMessage().observe(this){

        }
        mViewModel.getUser().observe(this){

        }
    }

    private fun validateFullName(): Boolean {
        var errorMessage: String? = null
        val value: String = mBinding.fullName.text.toString()
        if (value.isEmpty()) {
            errorMessage = "Enter your full name"
        }

        if (errorMessage != null) {
            mBinding.fullNameTil.apply {
                isErrorEnabled = true
                error = errorMessage
            }
        }

        return errorMessage == null
    }


    private fun validateEmail(): Boolean {
        var errorMessage: String? = null
        val value: String = mBinding.Email.text.toString()
        if (value.isEmpty()) {
            errorMessage = "Emter your email id"
        } else if (!Patterns.EMAIL_ADDRESS.matcher(value).matches()) {
            errorMessage = "EMail already exists"
        }
        if (errorMessage != null) {
            mBinding.EmailTil.apply {
                isErrorEnabled = true
                error = errorMessage
            }
        }
        return errorMessage == null
    }

    private fun validatePassword(): Boolean {
        var errorMessage: String? = null
        val value: String = mBinding.password.text.toString()
        if (value.isEmpty()) {
            errorMessage = "Password is required"
        } else if (value.length < 6) {
            errorMessage = "Password must be atleast of 6 char"
        }
        if (errorMessage != null) {
            mBinding.passwordTil.apply {
                isErrorEnabled = true
                error = errorMessage
            }
        }
        return errorMessage == null
    }

    private fun validateConPass(): Boolean {
        var errorMessage: String? = null
        val value: String = mBinding.passwordre.text.toString()
        if (value.isEmpty()) {
            errorMessage = "Reenter the password"
        } else if (value.length < 6) {
            errorMessage = "Password must be atleast of 6 char"
        }
        if (errorMessage != null) {
            mBinding.passwordretil.apply {
                isErrorEnabled = true
                error = errorMessage
            }
        }
        return errorMessage == null
    }

    private fun validatePassandConpass(): Boolean {
        var errorMessage: String? = null
        val password = mBinding.password.text.toString()
        val conpassword = mBinding.passwordre.text.toString()

        if (password != conpassword) {
            errorMessage = "confirm password does not match with password"
        }
        if (errorMessage != null) {
            mBinding.passwordretil.apply {
                isErrorEnabled = true
                error = errorMessage
            }
        }
        return errorMessage == null
    }


    override fun onKey(view: View?, event: Int, keyEvent: KeyEvent?): Boolean {
        return false
    }

    override fun onClick(view: View?) {
    }

    override fun onFocusChange(view: View?, hasFocus: Boolean) {
        if (view != null) {
            when (view.id) {
                R.id.fullName -> {
                    if (hasFocus) {
                        if (mBinding.fullNameTil.isErrorEnabled) {
                            mBinding.fullNameTil.isErrorEnabled = false
                        }
                    } else {
                        validateFullName()
                    }
                }

                R.id.Email -> {
                    if (hasFocus) {
                        if (mBinding.EmailTil.isErrorEnabled) {
                            mBinding.EmailTil.isErrorEnabled = false
                        }
                    } else {
                        validateEmail()
                    }
                }

                R.id.password -> {
                    if (hasFocus) {
                        if (mBinding.passwordTil.isErrorEnabled) {
                            mBinding.passwordTil.isErrorEnabled = false
                        }
                    } else {
                        if (validatePassword() && mBinding.passwordre.text!!.isNotEmpty() && validatePassandConpass() && validateConPass()) {
                            if (mBinding.passwordretil.isErrorEnabled) {
                                mBinding.passwordretil.isErrorEnabled = false
                            }
                            mBinding.passwordretil.apply {
                                setStartIconDrawable(R.drawable.baseline_check_circle_outline_24)
                                setStartIconTintList(ColorStateList.valueOf(Color.GREEN))
                            }


                        }
                    }
                }

                R.id.passwordre -> {
                    if (hasFocus) {
                        if (mBinding.passwordretil.isErrorEnabled) {
                            mBinding.passwordretil.isErrorEnabled = false
                        }
                    } else {
                        if (validatePassword() && validatePassandConpass() && validateConPass()) {
                            if (mBinding.passwordTil.isErrorEnabled) {
                                mBinding.passwordTil.isErrorEnabled = false
                            }
                            mBinding.passwordretil.apply {
                                setStartIconDrawable(R.drawable.baseline_check_circle_outline_24)
                                setStartIconTintList(ColorStateList.valueOf(Color.GREEN))
                            }
                        }
                    }
                }
            }
        }
    }
}