package com.example.authentication3.view_model

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.authentication3.repository.AuthRepository
import java.security.InvalidParameterException

class RegisterActivityViewModelFactory (val authRepository: AuthRepository, val application: Application): ViewModelProvider.Factory {
 @Suppress("UNCHECKED CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(RegisterActivityViewModel::class.java)){
            return RegisterActivityViewModel(authRepository,application) as T
        }
        throw InvalidParameterException("Unable to construct")
    }
}


