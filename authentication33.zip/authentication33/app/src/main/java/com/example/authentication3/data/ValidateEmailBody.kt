package com.example.authentication3.data

data class ValidateEmailBody(val email: String)
