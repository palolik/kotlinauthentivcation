package com.example.authentication3.data

data class UniqueEmailValidationResponse(val isUnique: Boolean, val user:User)
